<template>
  <div>
    您目前不具备访问该页面的权限
    <nuxt-link to="/">
      回到首页
    </nuxt-link>
  </div>
</template>
