import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2452c3be = () => interopDefault(import('..\\pages\\404.vue' /* webpackChunkName: "pages_404" */))
const _00a41d0e = () => interopDefault(import('..\\pages\\department.vue' /* webpackChunkName: "pages_department" */))
const _7ff618dc = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _5ca453dd = () => interopDefault(import('..\\pages\\role.vue' /* webpackChunkName: "pages_role" */))
const _24b842a2 = () => interopDefault(import('..\\pages\\space.vue' /* webpackChunkName: "pages_space" */))
const _6d0f7e5b = () => interopDefault(import('..\\pages\\unauthorized.vue' /* webpackChunkName: "pages_unauthorized" */))
const _5ca60cb2 = () => interopDefault(import('..\\pages\\user.vue' /* webpackChunkName: "pages_user" */))
const _13455f0a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/404",
    component: _2452c3be,
    name: "404"
  }, {
    path: "/department",
    component: _00a41d0e,
    name: "department"
  }, {
    path: "/login",
    component: _7ff618dc,
    name: "login"
  }, {
    path: "/role",
    component: _5ca453dd,
    name: "role"
  }, {
    path: "/space",
    component: _24b842a2,
    name: "space"
  }, {
    path: "/unauthorized",
    component: _6d0f7e5b,
    name: "unauthorized"
  }, {
    path: "/user",
    component: _5ca60cb2,
    name: "user"
  }, {
    path: "/",
    component: _13455f0a,
    name: "index"
  }, {
    path: "*",
    component: _2452c3be,
    name: "custom"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
