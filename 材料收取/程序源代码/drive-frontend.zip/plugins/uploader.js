import Vue from 'vue'
import uploader from 'vue-simple-uploader'

Vue.use(uploader)
