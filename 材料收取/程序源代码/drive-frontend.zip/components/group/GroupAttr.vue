<template>
  <div>
    共享空间属性设置
  </div>
</template>
