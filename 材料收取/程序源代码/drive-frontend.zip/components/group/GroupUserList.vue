<template>
  <div>
    共享空间用户成员列表
  </div>
</template>
