import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0adfec5e = () => interopDefault(import('..\\pages\\404.vue' /* webpackChunkName: "pages_404" */))
const _11e26386 = () => interopDefault(import('..\\pages\\group\\index.vue' /* webpackChunkName: "pages_group_index" */))
const _8018b2e2 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _e5f24e46 = () => interopDefault(import('..\\pages\\share\\index.vue' /* webpackChunkName: "pages_share_index" */))
const _ffb48900 = () => interopDefault(import('..\\pages\\file\\audio.vue' /* webpackChunkName: "pages_file_audio" */))
const _f24dff3c = () => interopDefault(import('..\\pages\\file\\doc.vue' /* webpackChunkName: "pages_file_doc" */))
const _40967e85 = () => interopDefault(import('..\\pages\\file\\image.vue' /* webpackChunkName: "pages_file_image" */))
const _88dcdc3c = () => interopDefault(import('..\\pages\\file\\trash.vue' /* webpackChunkName: "pages_file_trash" */))
const _773d4cb6 = () => interopDefault(import('..\\pages\\file\\video.vue' /* webpackChunkName: "pages_file_video" */))
const _37629226 = () => interopDefault(import('..\\pages\\group\\details.vue' /* webpackChunkName: "pages_group_details" */))
const _4722cce6 = () => interopDefault(import('..\\pages\\share\\details.vue' /* webpackChunkName: "pages_share_details" */))
const _bed42f06 = () => interopDefault(import('..\\pages\\share\\entry.vue' /* webpackChunkName: "pages_share_entry" */))
const _4600417d = () => interopDefault(import('..\\pages\\user\\details.vue' /* webpackChunkName: "pages_user_details" */))
const _1367f910 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/404",
    component: _0adfec5e,
    name: "404"
  }, {
    path: "/group",
    component: _11e26386,
    name: "group"
  }, {
    path: "/login",
    component: _8018b2e2,
    name: "login"
  }, {
    path: "/share",
    component: _e5f24e46,
    name: "share"
  }, {
    path: "/file/audio",
    component: _ffb48900,
    name: "file-audio"
  }, {
    path: "/file/doc",
    component: _f24dff3c,
    name: "file-doc"
  }, {
    path: "/file/image",
    component: _40967e85,
    name: "file-image"
  }, {
    path: "/file/trash",
    component: _88dcdc3c,
    name: "file-trash"
  }, {
    path: "/file/video",
    component: _773d4cb6,
    name: "file-video"
  }, {
    path: "/group/details",
    component: _37629226,
    name: "group-details"
  }, {
    path: "/share/details",
    component: _4722cce6,
    name: "share-details"
  }, {
    path: "/share/entry",
    component: _bed42f06,
    name: "share-entry"
  }, {
    path: "/user/details",
    component: _4600417d,
    name: "user-details"
  }, {
    path: "/",
    component: _1367f910,
    name: "index"
  }, {
    path: "*",
    component: _0adfec5e,
    name: "custom"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
