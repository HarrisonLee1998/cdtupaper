<template>
  <nuxt />
</template>
